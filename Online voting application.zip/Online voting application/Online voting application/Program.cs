﻿using System;
using System.Collections.Generic;

class VotingApplication
{
    private Dictionary<string, int> _candidates;

    public VotingApplication()
    {
        _candidates = new Dictionary<string, int>
        {
            { "Candidate A", 0 },
            { "Candidate B", 0 },
            { "Candidate C", 0 }
        };
    }

    public bool Vote(string candidateName)
    {
        if (_candidates.ContainsKey(candidateName))
        {
            _candidates[candidateName]++;
            return true;
        }

        return false;
    }

    public Dictionary<string, int> GetResults()
    {
        return _candidates;
    }
}

class Program
{
    static void Main()
    {
        var votingApp = new VotingApplication();

        // Simulating voting process
        string selectedCandidate = "Candidate A"; // Assume the user selected this candidate
        bool voteSuccessful = votingApp.Vote(selectedCandidate);

        if (voteSuccessful)
        {
            Console.WriteLine($"Vote for {selectedCandidate} successful!");
        }
        else
        {
            Console.WriteLine("Failed to vote. Invalid candidate selected.");
        }

        // Displaying results
        var results = votingApp.GetResults();
        foreach (var candidate in results)
        {
            Console.WriteLine($"{candidate.Key}: {candidate.Value} votes");
        }
    }
}
